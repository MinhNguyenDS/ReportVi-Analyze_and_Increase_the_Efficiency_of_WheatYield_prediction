﻿This README.txt file was generated on 2021-09-15 by M. Rahman

GENERAL INFORMATION

1. Data for the manuscript: Improving wheat yield prediction using secondary traits and high-density phenotyping under heat stressed environments. Front. Plant Sci. 12:633651. doi: 10.3389/fpls.2021.633651

2. Author Information
	A. Mohammad Mokhlesur Rahman
		Kansas State University
		mrahman@ksu.edu
	
	B. Jared Crain
		Kansas State University 
		jcrain@ksu.edu 

	C. Atena Haghighattalab
		University of Minnesota
		
	D. Ravi P. Singh
		International Maize and Wheat Improvement Center
	
	E. Jesse Poland
		Kansas State University

3. Field data collected from 2016-2020. 

4. Data collected at the Regional Agricultural Research Station (RARS), Bangladesh Agricultural Research Institute (BARI), Jamalpur, Bangladesh (N 24.93, E 89.93, 23 masl) from 2016-2020. Data collected and included within each year include:

	plot_id		Experimental plot number
	trial		Trial number that plot is recorded in
	rep			Replicate
	range		In plot design range that a plot is located in
	column			Column that plot is located in
	entry		Unique genotype entry in field plot
	
Hand measured phenotypic data include:
	
	DTHD		Days from planting until 50% of the plot at heading growth stage
	DAYSMT		Days from planting until 50% of the plot at maturity stage
	PH			Plant height measured in cm from base of plant to tip of spike
	 			excluding awns
	SN			Number of spikes per square meter
	SPKLNG		Length of spike from base to tip of spike in cm, excluding awns
	SPLN		Spikelet number per spike
	GRNSPK		Grains per spike
	TGW			Thousand kernel weight in grams
	GRYLD		Grain yield in tons (1000kg) per hectare
	 
High-throughput phenotyping data include:
	
	NDVI_{Date}	Normalized difference vegetation index collected on date as four
				digit year, two digit month, two digit day (i.e NDVI_20160121 is 
				NDVI measurement on January, 21, 2016)
	CT_{Date}	Canopy temperature measurement in degree Celsius collected on 
				specific day (i.e. CT_20160123 is CT measurement on January, 22, 
				2016)		 

5. The Bill & Melinda Gates Foundation (BMGF) and the	Foreign, Commonwealth andDevelopmentOffice (FCDO) of the	UK (formerly UK aid from the UK Government’s Department	for International Development, DfID) supported the	wheat breeding activities of CIMMYT through the Delivering	Genetic Gains in Wheat (DGGW) Project (OPPGD1389)	managed by the Cornell University and the Accelerating Genetic	Gains in Maize and Wheat (AGG) Project (INV-003439), and the CGIAR Research Program-WHEAT funders.



DATA & FILE OVERVIEW

Files include data files (.csv) and analysis files (.R).

1. Data files hosted on Dryad:

		README.txt			README file overview of the data.

		2016_Data.csv		Phenotypic data from 2016 wheat field trials.
	
		2017_Data.csv		Phenotypic data from 2017 wheat field trials.
		
		2018_Data.csv		Phenotypic data from 2018 wheat field trials.
	
		2019_Data.csv		Phenotypic data from 2019 wheat field trials.
		
		2020_Data.csv		Phenotypic data from 2020 wheat field trials.
		
	
	Analysis files on Zenodo include.
	
		BLUE_allYears.R		R code to calculate best linear unbiased 
		estimators for all years of data collection.
	
		Correlation_allYears.R	R code for correlations between variables
		for each year.
	
		Heritability_allYears.R	R code for trait heritability each year.
	
		Multivar_yieldpred_agron_allYear_R 		Yield prediction using
		agronomic traits.
	
		Multivar_yieldpred_alltrait_allYear.R	Yield prediction using 
		agronomic, CT, and NDVI traits.
	
		Multivar_yieldpred_ct_allYear_R		Yield prediction using only CT.
	
		Multivar_yieldpred_ndvi_allYear_R	Yield prediction using only NDVI.
	
		Multivar_yieldpred_ndvi_ct_allYear_R	Yield prediction using 
		NDVI and CT.
	
		Univar_yieldpred_allYears.R 		Single variable yield prediction.


2. Analysis should proceed from BLUE_allYears.R >  Correlation_allYears.R > Heritability_allYears.R followed by yield prediction (yieldpred) files.


